# Music Almanac

Archivio storico musicale internazionale e piattaforma di ricerca editoriale.

## Stack
- PostgreSQL 16
- Python 3.12 / FastAPI
- SQLAlchemy 2
- Alembic
- Docker Compose

## Avvio
1. Copiare `.env.example` in `.env`.
2. Eseguire `docker compose up --build`.
3. API: http://localhost:8000
4. Swagger: http://localhost:8000/docs
5. Health: http://localhost:8000/health

Il database è inizializzato tramite lo script `database/init/001_schema.sql` al primo avvio del volume.
Per modifiche successive allo schema usare Alembic: lo script di init è il bootstrap iniziale, non il sistema di migrazione operativo.

## Struttura
- `backend/`: API e accesso dati
- `database/`: bootstrap SQL e documentazione del modello
- `dashboard/`: punto di integrazione della dashboard esistente
- `docs/`: architettura e decisioni
- `scripts/`: utility operative

## Stato
Milestone 1: scaffolding infrastrutturale e modello relazionale iniziale.
La dashboard esistente non viene riscritta in questa milestone: sarà collegata agli endpoint REST dopo averne acquisito il sorgente.
