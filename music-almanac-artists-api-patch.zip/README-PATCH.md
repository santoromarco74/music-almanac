# Music Almanac — Artists API

Questa patch aggiunge il primo modulo applicativo del backend.

## Applicazione

Estrarre il contenuto dello ZIP nella cartella principale `music-almanac`,
mantenendo i percorsi e sovrascrivendo `backend/app/db.py` e `backend/app/main.py`.

La patch non contiene SQL di inizializzazione e non modifica lo schema PostgreSQL.
Non eseguire `docker compose down -v`: il flag `-v` elimina il volume del database.

Dalla cartella principale eseguire:

```powershell
docker compose up --build -d
docker compose logs -f api
```

Verificare `http://localhost:8000/health` e `http://localhost:8000/docs`.

## Endpoint

- GET `/api/v1/artists`
- POST `/api/v1/artists`
- GET `/api/v1/artists/{artist_id}`
- PATCH `/api/v1/artists/{artist_id}`
- DELETE `/api/v1/artists/{artist_id}`

La lista supporta `q`, `artist_type`, `country_code`, `offset` e `limit`.
Creazione e aggiornamento accettano `genre_ids`.

## Migrazioni

Questa patch mappa le tabelle create dal bootstrap SQL, ma non esegue Alembic.
La baseline Alembic deve essere predisposta separatamente dopo aver confrontato
il metadata ORM con lo schema PostgreSQL effettivo.
